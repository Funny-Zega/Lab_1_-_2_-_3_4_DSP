n = -10:10;
x = zeros(1, length(n));
x(n == -1) = 1;
x(n == 0)  = 1;
x(n == 1)  = 1;
x(n == 2)  = 1;
x(n == 3)  = 0.5;
x(n == 4)  = 0.5;

function val = get_x(target_n, n_axis, x_axis)
    val = zeros(1, length(target_n));
    for i = 1:length(target_n)
        idx = find(n_axis == target_n(i));
        if ~isempty(idx) then
            val(i) = x_axis(idx);
        end
    end
endfunction

clf(); 
// --- [ORIGINAL] x(n) ---
subplot(5,2,1);
plot2d3(n, x, 2); plot(n, x, 'bo'); 
xtitle("Original Signal x(n)", "n"); xgrid();

// --- (a) x(n-2) ---
subplot(5,2,2);
ya = get_x(n - 2, n, x);
plot2d3(n, ya, 5); plot(n, ya, 'r.'); 
xtitle("(a) Shift Right: x(n-2)", "n"); xgrid();

// --- (b) x(4-n) ---
subplot(5,2,3);
yb = get_x(4 - n, n, x);
plot2d3(n, yb, 3); plot(n, yb, 'g.'); 
xtitle("(b) Fold & Shift: x(4-n)", "n"); xgrid();

// --- (c) x(n+2) ---
subplot(5,2,4);
yc = get_x(n + 2, n, x);
plot2d3(n, yc, 4); plot(n, yc, 'c.'); 
xtitle("(c) Shift Left: x(n+2)", "n"); xgrid();

// --- (d) x(n)u(2-n) ---
subplot(5,2,5);
u_2n = zeros(1, length(n)); u_2n(n <= 2) = 1;
yd = x .* u_2n;
plot2d3(n, yd, 6); plot(n, yd, 'm.'); 
xtitle("(d) Windowing: x(n)u(2-n)", "n"); xgrid();

// --- (e) x(n-1)delta(n-3) ---
subplot(5,2,6);
ye = zeros(1, length(n));
ye(n == 3) = get_x(3 - 1, n, x);
plot2d3(n, ye, 7); plot(n, ye, 'k.'); 
xtitle("(e) Sampling: x(n-1)delta(n-3)", "n"); xgrid();

// --- (f) x(n^2) ---
subplot(5,2,7);
yf = get_x(n.^2, n, x);
plot2d3(n, yf, 13); plot(n, yf, 'r.'); 
xtitle("(f) Non-linear: x(n^2)", "n"); xgrid();

// --- (g) Even part of x(n) ---
subplot(5,2,8);
x_minus_n = get_x(-n, n, x);
yg = 0.5 * (x + x_minus_n);
plot2d3(n, yg, 2); plot(n, yg, 'b.'); 
xtitle("(g) Even part", "n"); xgrid();

// --- (h) Odd part of x(n) ---
subplot(5,2,9);
yh = 0.5 * (x - x_minus_n);
plot2d3(n, yh, 12); plot(n, yh, 'm.');
xtitle("(h) Odd part", "n"); xgrid();
