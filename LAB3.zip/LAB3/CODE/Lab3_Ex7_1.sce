
// ====================================================================
// 1. DEFINE NECESSARY FUNCTIONS
// ====================================================================

// Function for the original signal x(n)
function val = x_func(n_val)
    val = zeros(1, length(n_val));
    for i = 1:length(n_val)
        if (n_val(i) >= -3 & n_val(i) <= -1) then
            val(i) = 1 + n_val(i)/3;
        elseif (n_val(i) >= 0 & n_val(i) <= 3) then
            val(i) = 1;
        else
            val(i) = 0;
        end
    end
endfunction

// Function to generate unit impulse d(n)
function d = delta(n_val)
    d = zeros(1, length(n_val));
    d(n_val == 0) = 1;
endfunction

// Function to generate unit step u(n)
function u = step(n_val)
    u = zeros(1, length(n_val));
    u(n_val >= 0) = 1;
endfunction

// ====================================================================
// 2. CALCULATE SIGNALS
// ====================================================================
n = -10:10; // Use a common, wider time axis to accommodate all shifts

x_orig   = x_func(n);//a
y_b1     = x_func(-n + 4);//b1
y_b2     = x_func(-n - 4);//b2
y_c      = x_func(-n + 4);//c
x_part_e = (1/3)*delta(n+2) + (2/3)*delta(n+1) + step(n) - step(n-4);//e

// ====================================================================
// 3. PRINT THEORETICAL ANSWERS AND VALUES TO CONSOLE
// ====================================================================
clc(); 
disp("==================================================");
disp("ANSWER FOR PART (a):");
disp("   n |  x(n)");
disp("--------------");
n_val = -5:5;
x_val = x_func(n_val);

for i = 1:length(n_val)
    mprintf("%4d | %8.4f\n", n_val(i), x_val(i));
end

disp("==================================================");
disp("ANSWER FOR PART (d):");
disp("- COMPARISON:");
disp("  + Part (b1) [Fold then delay by 4] yields x(-(n-4)) = x(-n+4).");
disp("  + Part (b2) [Delay by 4 then fold] yields x(-n-4).");
disp("  + Part (c) is directly x(-n+4).");
disp("  -> The result of (c) is identical to (b1), but DIFFERENT from (b2).");
disp("  -> Conclusion: The order of operations (folding vs. shifting) matters.");
disp("");
disp("- RULE: To obtain the signal x(-n+k) from x(n), you have two valid methods:");
disp("  + Method 1: Fold first (get x(-n)), then DELAY by k samples (get x(-(n-k)) = x(-n+k)).");
disp("  + Method 2: ADVANCE first by k samples (get x(n+k)), then FOLD (get x(-n+k)).");

disp("==================================================");
disp("ANSWER FOR PART (e):");
disp("To express x(n) using unit impulses d(n) and unit steps u(n), we break the signal into two parts:");
disp("");
disp("  1. The isolated samples for n < 0:");
disp("     - At n = -2, amplitude is 1/3  => (1/3)*d(n+2)");
disp("     - At n = -1, amplitude is 2/3  => (2/3)*d(n+1)");
disp("");
disp("  2. The rectangular pulse for 0 <= n <= 3:");
disp("     - Amplitude is 1 from n=0 to n=3. This is a step function starting at 0, cut off at 4.");
disp("     - This can be formed by subtracting a delayed step from a normal unit step:");
disp("     => u(n) - u(n-4)");
disp("");
disp("  3. Combining everything together:");
disp("     x(n) = (1/3)*d(n+2) + (2/3)*d(n+1) + u(n) - u(n-4)");
disp("==================================================");
///////////////////////////////////////////////////////////////////////
//
// ====================================================================
// 4. PLOT ALL GRAPHS IN A SINGLE WINDOW
// ====================================================================
clf(); 
//Part a
subplot(3, 2, 1);
plot2d3(n, x_orig); plot(n, x_orig, 'bo');
xgrid(); xtitle("(a) Original signal: x(n)", "n", "Amplitude");

//Part b1
subplot(3, 2, 2);
plot2d3(n, y_b1); plot(n, y_b1, 'ro');
xgrid(); xtitle("(b1) Folded then delayed by 4: x(-n+4)", "n", "Amplitude");

//Part b2
subplot(3, 2, 3);
plot2d3(n, y_b2); plot(n, y_b2, 'go');
xgrid(); xtitle("(b2) Delayed by 4 then folded: x(-n-4)", "n", "Amplitude");

//Part c
subplot(3, 2, 4);
plot2d3(n, y_c); plot(n, y_c, 'mo');
xgrid(); xtitle("(c) Direct signal x(-n+4)", "n", "Amplitude");

//Part e
subplot(3, 1, 3); 
plot2d3(n, x_part_e); plot(n, x_part_e, 'ko'); 
xgrid(); xtitle("(e) Verification of x(n) using d(n) and u(n)", "n", "Amplitude");
