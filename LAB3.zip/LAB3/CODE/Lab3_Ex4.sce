clear; clc; clf;
funcprot(0); 
// --- ĐỊNH NGHĨA HÀM ADD (Cộng 2 tín hiệu) ---
function [yn, yorigin] = add(x1n, x1origin, x2n, x2origin)
    // 1. Tạo trục thời gian n riêng biệt cho x1 và x2
    n1 = (1:length(x1n)) - x1origin;
    n2 = (1:length(x2n)) - x2origin;

    // 2. Tìm giới hạn trục thời gian chung cho cả 2 tín hiệu
    min_n = min([n1, n2]);
    max_n = max([n1, n2]);
    n_y = min_n : max_n; 

    // 3. Khởi tạo mảng trung gian chứa toàn số 0 (Zero-padding)
    y1_padded = zeros(1, length(n_y));
    y2_padded = zeros(1, length(n_y));

    // 4. Nhúng x1 và x2 vào mảng trung gian ở đúng vị trí
    start1 = n1(1) - min_n + 1;
    start2 = n2(1) - min_n + 1;
    
    y1_padded(start1 : start1 + length(x1n) - 1) = x1n;
    y2_padded(start2 : start2 + length(x2n) - 1) = x2n;

    // 5. Tính tổng và xác định gốc yorigin
    yn = y1_padded + y2_padded;
    yorigin = 1 - min_n; 

    f = gcf();
    clf; 
    f.figure_size = [800, 900];

    // Giới hạn trục chung đồng nhất cho cả 3 hình
    limit_n_min = min_n - 1;
    limit_n_max = max_n + 1;
    min_val = min([x1n, x2n, yn]) - 3;
    max_val = max([x1n, x2n, yn]) + 3;

    // --- 1. Vẽ đồ thị Tín hiệu x1(n) ---
    subplot(3, 1, 1);
    plot2d3(n1, x1n, style=2); 
    e1 = gce(); e1.children.thickness = 3;
    plot(n1, x1n, 'ro', 'markersize', 10);
    
    for i = 1:length(n1)
        xstring(n1(i), x1n(i) + 0.8, string(x1n(i)));
        txt = gce(); txt.font_size = 3; txt.font_foreground = 2; // Màu đỏ
    end
    
    title('Signal x1(n)', 'fontsize', 4);
    xlabel('n'); ylabel('Amplitude');
    xgrid(color('gray'));
    a1 = gca(); a1.data_bounds = [limit_n_min, min_val; limit_n_max, max_val];

    // --- 2. Vẽ đồ thị Tín hiệu x2(n) ---
    subplot(3, 1, 2);
    plot2d3(n2, x2n, style=5); 
    e2 = gce(); e2.children.thickness = 3;
    plot(n2, x2n, 'bo', 'markersize', 10);
    
    for i = 1:length(n2)
        xstring(n2(i), x2n(i) + 0.8, string(x2n(i)));
        txt = gce(); txt.font_size = 3; txt.font_foreground = 5;
    end
    
    title('Signal x2(n)', 'fontsize', 4);
    xlabel('n'); ylabel('Amplitude');
    xgrid(color('gray'));
    a2 = gca(); a2.data_bounds = [limit_n_min, min_val; limit_n_max, max_val];

    // --- 3. Vẽ đồ thị Tín hiệu tổng y(n) ---
    subplot(3, 1, 3);
    plot2d3(n_y, yn, style=3); 
    e3 = gce(); e3.children.thickness = 3;
    plot(n_y, yn, 'go', 'markersize', 10);
    
    for i = 1:length(n_y)
        xstring(n_y(i), yn(i) + 0.8, string(yn(i)));
        txt = gce(); txt.font_size = 3; txt.font_foreground = 3; 
    end
    
    title('Result y(n) = x1(n) + x2(n)', 'fontsize', 4);
    xlabel('n'); ylabel('Amplitude');
    xgrid(color('gray'));
    a3 = gca(); a3.data_bounds = [limit_n_min, min_val; limit_n_max, max_val];

endfunction

//[yn, yorigin] = add([0, 1, 3, -2], 1, [2, 3, 5, 1], 2);
//disp("Mảng kết quả yn = "); disp(yn);
//disp("Vị trí gốc yorigin = "); disp(yorigin);
[yn, yorigin] = add([0, 1, 3, -2], 1, [1, 1, 2, 3], 2);
disp("Mảng kết quả yn = "); disp(yn);
disp("Vị trí gốc yorigin = "); disp(yorigin);
