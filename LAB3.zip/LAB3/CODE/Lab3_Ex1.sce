clear; clc; clf;
funcprot(0);
function [yn, yorigin] = delay(xn, xorigin, k)
    // 1. Tính toán giá trị và gốc tọa độ mới
    yn = xn;
    yorigin = xorigin - k;

    // 2. Tự động tạo trục thời gian n dựa trên vị trí gốc
    n_x = (1:length(xn)) - xorigin;
    n_y = (1:length(yn)) - yorigin;

    // 3. Cài đặt cửa sổ đồ họa
    f = gcf();
    clf;
    f.figure_size = [800, 700];
    
    min_n = min([n_x, n_y]) - 1;
    max_n = max([n_x, n_y]) + 1;
    min_val = min([xn, yn]) - 2;
    max_val = max([xn, yn]) + 3; 
    // 4. Vẽ đồ thị Tín hiệu gốc x(n)
    subplot(2, 1, 1);
    plot2d3(n_x, xn, style=2); 
    e1 = gce(); e1.children.thickness = 3;
    plot(n_x, xn, 'ro', 'markersize', 10);
    
    // Hiển thị số cho x(n)
    for i = 1:length(n_x)
        xstring(n_x(i), xn(i) + 0.8, string(xn(i)));
        txt = gce(); txt.font_size = 3; txt.font_foreground = 2; // Màu đỏ
    end
    
    title('Original Signal x(n)', 'fontsize', 4);
    xlabel('n'); ylabel('Amplitude');
    xgrid(color('gray'));
    a1 = gca(); a1.data_bounds = [min_n, min_val; max_n, max_val];

    // 5. Vẽ đồ thị Tín hiệu trễ y(n)
    subplot(2, 1, 2);
    plot2d3(n_y, yn, style=5); 
    e2 = gce(); e2.children.thickness = 3;
    plot(n_y, yn, 'bo', 'markersize', 10);
    
    for i = 1:length(n_y)
        xstring(n_y(i), yn(i) + 0.8, string(yn(i)));
        txt = gce(); txt.font_size = 3; txt.font_foreground = 5;
    end
    
    //Cập nhật tiêu đề
    title('Delayed Signal y(n) = x(n - ' + string(k) + ')', 'fontsize', 4); 
    xlabel('n'); ylabel('Amplitude');
    xgrid(color('gray'));
    a2 = gca(); a2.data_bounds = [min_n, min_val; max_n, max_val];
    
endfunction
