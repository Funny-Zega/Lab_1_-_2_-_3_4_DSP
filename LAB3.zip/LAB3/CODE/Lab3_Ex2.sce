clear; clc; clf;
funcprot(0); 
function [yn, yorigin] = advance(xn, xorigin, k)
    // 1. Tính toán giá trị và gốc tọa độ mới
    yn = xn;
    yorigin = xorigin + k;

    // 2. Tự động tạo trục thời gian n dựa trên vị trí gốc
    n_x = (1:length(xn)) - xorigin;
    n_y = (1:length(yn)) - yorigin;

    // 3. Cài đặt cửa sổ đồ họa chuẩn
    f = gcf();
    clf; // Xóa hình cũ
    f.figure_size = [800, 700]; // Phóng to cửa sổ

    // Tìm giới hạn trục chung để 2 đồ thị thẳng hàng nhau (căn lề trục n đồng nhất)
    min_n = min([n_x, n_y]) - 1;
    max_n = max([n_x, n_y]) + 1;
    
    // Nới rộng trần đồ thị lên trên/xuống dưới ít nhất 3 đơn vị để chống lẹm chữ
    min_val = min([xn, yn]) - 3;
    max_val = max([xn, yn]) + 3; 

    // 4. Vẽ đồ thị Tín hiệu gốc x(n)
    subplot(2, 1, 1);
    plot2d3(n_x, xn, style=2); // Thanh tín hiệu màu đỏ
    e1 = gce(); e1.children.thickness = 3; // Nét thanh đậm
    plot(n_x, xn, 'ro', 'markersize', 10); // Dấu chấm đỏ to
    
    // Hiển thị số cho x(n)
    for i = 1:length(n_x)
        xstring(n_x(i), xn(i) + 0.8, string(xn(i)));
        txt = gce(); txt.font_size = 3; txt.font_foreground = 2; 
    end
    
    title('Original Signal x(n)', 'fontsize', 4);
    xlabel('n'); ylabel('Amplitude');
    xgrid(color('gray')); // Bật lưới xám
    a1 = gca(); a1.data_bounds = [min_n, min_val; max_n, max_val]; 

    // 5. Vẽ đồ thị Tín hiệu dịch trước y(n)
    subplot(2, 1, 2);
    plot2d3(n_y, yn, style=5); 
    e2 = gce(); e2.children.thickness = 3;
    plot(n_y, yn, 'bo', 'markersize', 10); 
    
    
    for i = 1:length(n_y)
        xstring(n_y(i), yn(i) + 0.8, string(yn(i)));
        txt = gce(); txt.font_size = 3; txt.font_foreground = 5; 
    end
    
    
    title('Advanced Signal y(n) = x(n + ' + string(k) + ')', 'fontsize', 4); 
    xlabel('n'); ylabel('Amplitude');
    xgrid(color('gray')); 
    a2 = gca(); a2.data_bounds = [min_n, min_val; max_n, max_val]; 
    
endfunction


[yn, yorigin] = advance([1, -2, 3, 6], 3, 2);
