n = -2:2;
x = [2, 3, 4, 5, 6];
x_minus_n = x($:-1:1);
xe = 0.5 * (x + x_minus_n);
xo = 0.5 * (x - x_minus_n);


disp("Even Component xe(n):");
disp(xe);
disp("Odd Component xo(n):");
disp(xo);


clf(); 

subplot(3, 1, 1);
plot2d3(n, x, 2); 
plot(n, x, 'bo');
xtitle("Original Signal x(n)", "n", "Amplitude");
xgrid();


subplot(3, 1, 2);
plot2d3(n, xe, 3); 
plot(n, xe, 'go');
xtitle("Even Component x_e(n)", "n", "Amplitude");
xgrid();


subplot(3, 1, 3);
plot2d3(n, xo, 5); 
plot(n, xo, 'ro');
xtitle("Odd Component x_o(n)", "n", "Amplitude");
xgrid();


