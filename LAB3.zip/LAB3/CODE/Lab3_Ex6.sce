clear; clc; clf;
funcprot(0); 
// --- ĐỊNH NGHĨA HÀM CONVOLUTION (Tích chập 2 tín hiệu) ---
function [yn, yorigin] = convolution(xn, xorigin, hn, horigin)
    // 1. Tính toán mảng giá trị tích chập dùng hàm có sẵn của Scilab
    yn = convol(xn, hn); 
    
    // 2. Xác định vị trí gốc tọa độ của tín hiệu ngõ ra y(n)
    yorigin = xorigin + horigin - 1;

    // 3. Tạo trục thời gian n riêng biệt cho x, h và y
    n_x = (1:length(xn)) - xorigin;
    n_h = (1:length(hn)) - horigin;
    n_y = (1:length(yn)) - yorigin;

    // --- CÀI ĐẶT CỬA SỔ ĐỒ HỌA CHUẨN ---
    f = gcf();
    clf; 
    f.figure_size = [800, 900]; 

    limit_n_min = min(n_y) - 1; 
    limit_n_max = max(n_y) + 1;
    
    min_val = min([xn, hn, yn]) - 3; 
    max_val = max([xn, hn, yn]) + 3;

    // --- 1. Vẽ đồ thị Tín hiệu đầu vào x(n) ---
    subplot(3, 1, 1);
    plot2d3(n_x, xn, style=2); 
    e1 = gce(); e1.children.thickness = 3;
    plot(n_x, xn, 'ro', 'markersize', 10);
    
    for i = 1:length(n_x)
        xstring(n_x(i), xn(i) + 0.8, string(xn(i)));
        txt = gce(); txt.font_size = 3; txt.font_foreground = 2; 
    end
    
    title('Input Signal x(n)', 'fontsize', 4);
    xlabel('n'); ylabel('Amplitude');
    xgrid(color('gray'));
    a1 = gca(); a1.data_bounds = [limit_n_min, min_val; limit_n_max, max_val];

    // --- 2. Vẽ đồ thị Hệ thống đáp ứng xung h(n) ---
    subplot(3, 1, 2);
    plot2d3(n_h, hn, style=5); 
    e2 = gce(); e2.children.thickness = 3;
    plot(n_h, hn, 'bo', 'markersize', 10);
    
    for i = 1:length(n_h)
        xstring(n_h(i), hn(i) + 0.8, string(hn(i)));
        txt = gce(); txt.font_size = 3; txt.font_foreground = 5;
    end
    
    title('System Characteristic h(n)', 'fontsize', 4);
    xlabel('n'); ylabel('Amplitude');
    xgrid(color('gray'));
    a2 = gca(); a2.data_bounds = [limit_n_min, min_val; limit_n_max, max_val];

    // --- 3. Vẽ đồ thị Tín hiệu tích chập y(n) ---
    subplot(3, 1, 3);
    plot2d3(n_y, yn, style=3); 
    e3 = gce(); e3.children.thickness = 3;
    plot(n_y, yn, 'go', 'markersize', 10);
    
    for i = 1:length(n_y)
        xstring(n_y(i), yn(i) + 0.8, string(yn(i)));
        txt = gce(); txt.font_size = 3; txt.font_foreground = 3; 
    end
    
    title('Convolution Result y(n) = x(n) * h(n)', 'fontsize', 4);
    xlabel('n'); ylabel('Amplitude');
    xgrid(color('gray'));
    a3 = gca(); a3.data_bounds = [limit_n_min, min_val; limit_n_max, max_val];

endfunction

[yn, yorigin] = convolution([1, 2, 3], 1, [1, 1,2], 1);
disp("Mảng kết quả yn = "); disp(yn);
disp("Vị trí gốc yorigin = "); disp(yorigin);
