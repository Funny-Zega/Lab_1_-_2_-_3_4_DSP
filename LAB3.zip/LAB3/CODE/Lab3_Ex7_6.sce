// ---------------------------------------------------------
// 1. KHAI BÁO HÀM 
// ---------------------------------------------------------
function val = get_val(target_n, n_axis, sig)
    val = zeros(1, length(target_n));
    for i = 1:length(target_n)
        idx = find(n_axis == target_n(i));
        if length(idx) > 0 then 
            val(i) = sig(idx(1)); 
        end
    end
endfunction

// ---------------------------------------------------------
// 2. KHỞI TẠO TÍN HIỆU GỐC VÀ TRỤC THỜI GIAN
// ---------------------------------------------------------
n = -5:10;
x = zeros(1, length(n));
x(find(n >= 0 & n <= 3)) = 1; 

// ---------------------------------------------------------
// 3. TÍNH TOÁN CÁC BIẾN ĐỔI 
// ---------------------------------------------------------
y = get_val(n .^ 2, n, x);
y_delayed = get_val(n - 2, n, y);
x_delayed = get_val(n - 2, n, x);
y2 = get_val(n .^ 2, n, x_delayed);

// ---------------------------------------------------------
// 4. VẼ 5 ĐỒ THỊ
// ---------------------------------------------------------
clf(); 
f = gcf();
f.figure_size = [800, 1000]; 

// (1)x(n)
subplot(5,1,1);
plot2d3(n, x, 2); plot(n, x, 'bo');
xtitle("(1) Input Signal: x(n)", "n", "Amplitude");
xgrid();

// (2)y(n)
subplot(5,1,2);
plot2d3(n, y, 5); plot(n, y, 'ro');
xtitle("(2) Output Signal: y(n) = x(n^2)", "n", "Amplitude");
xgrid();

// (3)y(n-2)
subplot(5,1,3);
plot2d3(n, y_delayed, 3); plot(n, y_delayed, 'go');
xtitle("(3) Delayed Output: y_delayed(n) = y(n-2)", "n", "Amplitude");
xgrid();

// (4)x_2(n)
subplot(5,1,4);
plot2d3(n, x_delayed, 2); plot(n, x_delayed, 'bo');
xtitle("(4) Delayed Input: x_2(n) = x(n-2)", "n", "Amplitude");
xgrid();

// (5)y_2(n)
subplot(5,1,5);
plot2d3(n, y2, 6); plot(n, y2, 'mo');
xtitle("(5) Output to Delayed Input: y_2(n) = x_2(n^2)", "n", "Amplitude");
xgrid();
